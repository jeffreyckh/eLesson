PHP Calendar
Created by Corey Worrell (http://coreyworrell.com), with a little help from the Kohana Framework (http://kohanaframework.org) guys.

Examples and documenation can be found here: http://coreyworrell.com/calendar/